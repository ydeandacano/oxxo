package mx.edu.utng.ydeanda.oxxito2019;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ListaProductosActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

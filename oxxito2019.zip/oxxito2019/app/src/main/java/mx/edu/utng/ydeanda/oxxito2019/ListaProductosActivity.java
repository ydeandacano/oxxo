package mx.edu.utng.ydeanda.oxxito2019;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.view.View;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.edu.utng.ydeanda.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.ydeanda.oxxito2019.model.Producto;


public class ListaProductosActivity extends AppCompatActivity {
    private Button btnNuevo;
    private ListView lsvProductos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_productos);
        btnNuevo = (Button)findViewById(R.id.btn_agregar_producto);
        lsvProductos = (ListView)findViewById(R.id.lsv_productos);

        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view){
                Intent intNuevoProducto = new Intent(getApplicationContext(),
                        NuevoProductoActivity.class);
                        startActivity(intNuevoProducto);
            }
        });
        //Se crea un objeto DAO para consultar todos los productos

        ProductoDAO dao= new ProductoDAO(getApplicationContext());
        //Se crea un objeto para la lista de productos
        List<Producto>listaProducto;

        try{
            listaProducto = dao.getAll();
            List<HashMap<String,String>> filas = new ArrayList<HashMap<String, String>>();
            HashMap<String, String> registro;
            for (Producto prod: listaProducto){
                registro = new HashMap<String, String>();
                registro.put("codigo", prod.getCodigo());
                registro.put("nombre", prod.getNombre());
                registro.put("precio", String.valueOf(prod.getPrecio()));
                filas.add(registro);
            }
            SimpleAdapter adaptador = new SimpleAdapter(getApplicationContext(), filas, R.layout.activity_registro_producto, new String[]{"codigo", "nombre", "precio"}, new int[]{R.id.text_codigo2, R.id.text_producto2, R.id.text_precio2});
            lsvProductos.setAdapter(adaptador);
            lsvProductos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                        TextView txtCodigo = (TextView)arg1.findViewById(R.id.text_codigo2);
                        Bundle bundle = new Bundle();
                        bundle.putString("codigo", txtCodigo.getText().toString());

                        Intent intGestionProductoActivity = new Intent(getApplicationContext(), GestionProductoActivity.class);
                        intGestionProductoActivity.putExtras(bundle);
                        startActivity(intGestionProductoActivity);
                }
            });


        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "Error "+ e.getMessage(), Toast.LENGTH_LONG).show();
        }


    }
}

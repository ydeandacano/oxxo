package mx.edu.utng.ydeanda.oxxito2019.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Conexion {
    //Se define una variable Context a partir de esta se crea la BD
    private Context contexto;
    public Conexion(Context contexto){
        this.contexto = contexto;
    }

    /**
     * Método para abrir la conexión de datos
     *
     * @return
     */
    private SQLiteDatabase abrirConexion(){
        //Se crea un objeto SQLiteDatabase
        SQLiteDatabase conexion= contexto.openOrCreateDatabase(
                "oxxito.db", //Nombre DB
                SQLiteDatabase.OPEN_READWRITE, //Modo lecturaa
                null);
        return conexion;
    }

    /**
     * Métoco para cerrar conexión
      * @param conexion
     */
    private void cerrarConexion(SQLiteDatabase conexion){
        if(conexion!=null){
            conexion.close();
        }
    }

    /**
     * Método para ejecutar sentencias de sQL como insert, update y delete
     * @return
     * @param sentencia
     */
    public boolean ejecutarSentencia(String sentencia)throws Exception{
        //Se abre la conexion con la base de datos
        SQLiteDatabase conexion = abrirConexion();
        try{
            //Se ejecuta la sentencia sobre la conexion
            conexion.execSQL(sentencia);
            //Se cierra la conexion
            conexion.close();
        }catch (Exception e){
            //Lanzamos la conexión al metodo que invoca
            throw new Exception("Error en la sentencia:" + e.getMessage());

        }
        return true;
    }

    public List<HashMap<String, String>> ejecutarConsulta(String tabla, String[] campos, String condicion) throws Exception{
        //Se crea la lista de onjetos HashMap, donde cada HashMap representará un objeto de la BD
        List<HashMap <String, String>>datos = new ArrayList<HashMap<String, String>>();
        try {
            //Se abre la eonexion
            SQLiteDatabase conexion = abrirConexion();
            //Consulta la DB, de acuerdo a los parametros señalados
            Cursor resultado = conexion.query(tabla, campos, condicion, null, null, null, null);
            HashMap<String, String> registro;
            //Se itera sobre cada uno de los registros arrojados por la consulta
            while (resultado.moveToNext()) {
                //Para cada registro en la BD, se crea un HashMap
                registro = new HashMap<String, String>();
                for(int i=0; i<campos.length; i++){
                    //Por cada campo se inserta el nombre y el valor
                    registro.put(campos[i], resultado.getString(i));
                }
                //Agregamos el registro a la lista
                datos.add(registro);
            }

            //Se cierra conexion
            conexion.close();

        }catch (Exception e){
            throw new Exception("Error al ejecutar la consulta: "+ e.getMessage());
        }
        return datos;
    }

    /**
     * Método para inicializar la BD
     */
    public void inicializarBD()throws Exception{
        //Se abre la conexion a la base de datos
        SQLiteDatabase conexion = abrirConexion();
        //Se ejecuta la sentencia para borrar la tabla de productos
        conexion.execSQL("DROP TABLE IF EXISTS PRODUCTOS");
        //Se ejecuta la sentencia para crear tabla de productos
        conexion.execSQL("CREATE TABLE PRODUCTOS(codigo TEXT,"+"nombre TEXT, precio REAL, existencias INTEGER,"+"fecha_caducidad TEXT)");
        //Se cierra la tabla
        conexion.close();
    }
}



package mx.edu.utng.ydeanda.oxxito2019;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

import mx.edu.utng.ydeanda.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.ydeanda.oxxito2019.model.Producto;


public class NuevoProductoActivity extends AppCompatActivity {
    private EditText txtCodigo;
    private EditText txtNombre;
    private EditText txtCaducidad;
    private EditText txtPrecio;
    private EditText txtExistencias;
    private Button btnGuardar;
    private Button btnCancelar;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_producto);
        //Inflate

        txtCodigo=(EditText)findViewById(R.id.txt_codigo);
        txtNombre=(EditText)findViewById(R.id.txt_producto);
        txtPrecio=(EditText)findViewById(R.id.txt_precio);
        txtCaducidad=(EditText)findViewById(R.id.txt_fecha_caducidad);
        txtExistencias=(EditText)findViewById(R.id.txt_existencia);
        btnGuardar=(Button)findViewById(R.id.btn_Guardar);
        btnCancelar=(Button)findViewById(R.id.btn_Cancelar);

        //2. Asignamos un escuchador al botón Guardar
        btnGuardar.setOnClickListener(new View.OnClickListener() {
          @Override
            public void onClick(View view){
              Producto p = new Producto();

              p.setCodigo(txtCodigo.getText().toString());
              p.setNombre(txtNombre.getText().toString());
              p.setPrecio(Double.parseDouble(txtPrecio.getText().toString()));
              p.setExistencias(Integer.valueOf(txtExistencias.getText().toString()));
              p.setFechaCaducidad(txtCaducidad.getText().toString());
              //Se crea un objeto DAO para almacenar el objeto
              ProductoDAO dao = new ProductoDAO(getApplicationContext());
              //Se intenta realizar los cambios
              try{
                  dao.insertar(p);

              Toast.makeText(getApplicationContext(),"Guardando", Toast.LENGTH_SHORT).show();
              System.exit(0);
          }catch (Exception e){
                  Toast.makeText(getApplicationContext(),"Error: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                  System.exit(0);
              }
          }
        });
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
    }
}

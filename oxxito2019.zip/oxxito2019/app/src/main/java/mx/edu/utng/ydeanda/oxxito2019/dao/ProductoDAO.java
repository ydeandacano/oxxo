package mx.edu.utng.ydeanda.oxxito2019.dao;

import android.content.Context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.edu.utng.ydeanda.oxxito2019.model.Producto;

public class ProductoDAO {
    private Context contexto;

    public ProductoDAO(Context contexto) {
        this.contexto = contexto;
    }

    /**
     * Método para insertar un objeto producto a la BD
     *
     * @param obj
     */
    public void insertar(Producto obj) throws Exception {
        //Se crea la sentencia SQL valida
        String comando = "INSERT INTO PRODUCTOS(codigo, nombre, precio, existencias, fecha_caducidad)" + "VALUES"+"('" + obj.getCodigo() + "', '" + obj.getNombre() + "'," + obj.getPrecio() + "," + obj.getExistencias() + "," + obj.getFechaCaducidad() + "')";
        Conexion con = new Conexion(contexto);
        try {
            con.ejecutarSentencia(comando);
        } catch (Exception e) {
            throw new Exception("error al insertar: " + e.getMessage());
        }
    }

    /**
     * Método para actualizar un objeto producto
     */

    public void update(Producto obj) throws Exception {
        //Se crea la sentencia SQL al ejecutar
        String comando = "UPDATE PRODUCTOS SET" + "nombre='" + obj.getNombre() + "'," + "precio=" + obj.getPrecio() + "," + "existencias=" + obj.getExistencias() + ",'" + "fecha_caducidad= '" + obj.getFechaCaducidad() + "' WHERE codigo='" + obj.getCodigo() + "'";
        //Se crea el objeto de conexión
        Conexion con = new Conexion(contexto);
        try {
            //Se ejecuta la senetcnia
            con.ejecutarSentencia(comando);
        } catch (Exception e) {
            //Lanzamos la excepcion en caso de error
            throw new Exception("Error al actualizar" + e.getMessage());
        }
    }

    public void delete(Producto obj)throws Exception  {
        //Se crea la sentencia delete
        String comando = "DELETE FROM PRODUCTOS WHERE codigo='" + obj.getCodigo() + "'";
        //Se crea el objeto de conexión
        Conexion con = new Conexion(contexto);
        try {
            //Se ejecuta la senetcnia
            con.ejecutarSentencia(comando);
        } catch (Exception e) {
            //Lanzamos la excepcion en caso de error
            throw new Exception("Error al eliminar: " + e.getMessage());
        }
    }


    public List<Producto> getAll() throws Exception{
        //Se especifica el nombre de la tabla a cinsultar
        String tabla = "PRODUCTOS";
        //Se indica los campos a consultar de la tabla
        String campos[] = new String[]{"codigo", "nombre", "precio", "existencias", "fecha_caducidad"};
        //Se crea una lista para almacenar los objetos producto almacenados
        List<Producto> listaProductos = new ArrayList<Producto>();
        //Se abre la conexion a la BD
        Conexion con = new Conexion(contexto);
        //Se consulta mediante la conexion todos los registros y campos
        List<HashMap<String, String>> resultado;
        resultado = con.ejecutarConsulta(tabla, campos, null);
        //Se crea una referencia a un objeto Producto
        Producto pro;
        //Se recorrre cada uno de los registros regresados de la consulta
        for (HashMap<String, String> reg: resultado){
            //Por cada registrp se crea un objeto Producto
            pro = new Producto();
            //Se asigna cada uno de los atributos del objeto producto
            pro.setCodigo(reg.get("codigo"));
            pro.setNombre(reg.get("nombre"));
            pro.setPrecio(Double.valueOf(reg.get("precio")));
            Integer.valueOf(reg.get("existencias"));
            pro.setFechaCaducidad(reg.get("fecha_caducidad"));
            //Se inserta el objeto al producto en la lista
            listaProductos.add(pro);
        }
        return  listaProductos;
    }

    public Producto getById(Producto obj) throws Exception{
        //Se especifica el nombre de la tabla a cinsultar
        String tabla = "PRODUCTOS";
        //Se indica los campos a consultar de la tabla
        String campos[] = new String[]{"codigo", "nombre", "precio", "existencias", "fecha_caducidad"};
        //Se especifica la condicion para realizar la consulta
        String condicion = "codigo ='"+obj.getCodigo()+"'";
        //Se abre la conexion a la BD
        Conexion con = new Conexion(contexto);
        //Se consulta mediante la conexion todos los registros y campos
        List<HashMap<String, String>> resultado;
        resultado = con.ejecutarConsulta(tabla, campos, condicion);
        //Se crea la referencia a un objeto Producto
        Producto pro = null;
        for (HashMap<String, String> reg: resultado){
            //Por cada registrp se crea un objeto Producto
            pro = new Producto();
            //Se asigna cada uno de los atributos del objeto producto
            pro.setCodigo(reg.get("codigo"));
            pro.setNombre(reg.get("nombre"));
            pro.setPrecio(Double.valueOf(reg.get("precio")));
            Integer.valueOf(reg.get("existencias"));
            pro.setFechaCaducidad(reg.get("fecha_caducidad"));
        }
        return pro;
    }


    }

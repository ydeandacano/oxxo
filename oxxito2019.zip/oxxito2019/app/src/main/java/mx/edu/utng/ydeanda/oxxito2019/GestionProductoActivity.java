package mx.edu.utng.ydeanda.oxxito2019;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import mx.edu.utng.ydeanda.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.ydeanda.oxxito2019.model.Producto;

public class GestionProductoActivity extends AppCompatActivity{
    private EditText txtCodigo;
    private EditText txtNombre;
    private EditText txtPrecio;
    private EditText txtExistencias;
    private EditText txtFechaCaducidad;
    private Button btnActualizar;
    private Button btnCancelar;
    private Button btnEliminar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_producto);
        //1. Se relacionan los controles entre la vista y la actividad;
        txtCodigo = (EditText)findViewById(R.id.txt_codigo);
        txtNombre = (EditText)findViewById(R.id.txt_producto);
        txtPrecio = (EditText)findViewById(R.id.txt_precio);
        txtFechaCaducidad = (EditText)findViewById(R.id.txt_fecha_caducidad);
        txtExistencias = (EditText)findViewById(R.id.txt_existencia);
        btnActualizar = (Button) findViewById(R.id.btn_actualizar);
        btnCancelar = (Button) findViewById(R.id.btn_Cancelar);
        btnEliminar = (Button) findViewById(R.id.btn_eliminar);

        //2. Se obtiene el valor CODIGO_DE_BARRAS de un bundle de la actividad
        String codigo = getIntent().getExtras().getString("codigo");
        //3. Se crea un objeto Producto
        Producto p = new Producto();
        //4. Se le asigna el codigo de barras al objeto al producto;
        p.setCodigo(codigo);
        //5. Se crea un objeto DAO para buscar el producto
        ProductoDAO dao = new ProductoDAO(getApplicationContext());
        try{
            p = dao.getById(p);

            //En caso de exito se asignan los valores a los controles
            txtCodigo.setText(p.getCodigo());
            txtNombre.setText(p.getNombre());
            txtExistencias.setText(p.getExistencias());
            txtFechaCaducidad.setText(p.getFechaCaducidad());
            txtPrecio.setText(""+ p.getPrecio());


        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "Error "+ e.getMessage(), Toast.LENGTH_LONG).show();
        }
        //6. Se agrega un escuchador de eventos al botón Actualizar
        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view){
                //Se crea objeto Prodicto
                Producto p = new Producto();
                //Se asignan los datos a los atributos del objeto
                p.setCodigo(txtCodigo.getText().toString());
                p.setNombre(txtNombre.getText().toString());
                p.setPrecio(Double.parseDouble(txtPrecio.getText().toString()));
                p.setExistencias(Integer.valueOf(txtExistencias.getText().toString()));
                p.setFechaCaducidad(txtFechaCaducidad.getText().toString());
                //Se crea un objeto DAO para almacenar el objeto
                ProductoDAO dao = new ProductoDAO(getApplicationContext());
                //Se intenta realizar los cambios
                try{
                    dao.update(p);
                    Toast.makeText(getApplicationContext(), "Producto actualizado", Toast.LENGTH_SHORT).show();
                    System.exit(0);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        //7. Se agrega un escuchador de eventos al botón eliminar
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Se crea un objeto Producto
                Producto p= new Producto();
                //Se asignan sus atributos
                p.setCodigo(txtCodigo.getText().toString());

                //Se crea un objeto DAO
                ProductoDAO dao= new ProductoDAO(getApplicationContext());
                //Se intenta eliminar el objeto
                try{
                    dao.delete(p);
                    //Se muestra mensaje de exito
                    Toast.makeText(getApplicationContext(), "Producto eliminado", Toast.LENGTH_SHORT).show();
                    System.exit(0);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();

                }
            }
        });

        //8. Se asigna un escuchador de eventos al botón Cancelar
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
    }
}

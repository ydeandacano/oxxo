package mx.edu.utng.ydeanda.oxxito2019;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ListView;
import android.view.View;


public class ListaProductosActivity extends AppCompatActivity {
    private Button btnNuevo;
    private ListView lsvProductos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_productos);
        btnNuevo = (Button)findViewById(R.id.btn_agregar_producto);
        lsvProductos = (ListView)findViewById(R.id.lsv_productos);

        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view){
                Intent intNuevoProducto = new Intent(getApplicationContext(),
                        NuevoProductoActivity.class);
                        startActivity(intNuevoProducto);
            }
        });
    }
}

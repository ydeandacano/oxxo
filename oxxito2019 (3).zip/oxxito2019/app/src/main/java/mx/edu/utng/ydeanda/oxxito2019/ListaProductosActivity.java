package mx.edu.utng.ydeanda.oxxito2019;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.view.View;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.edu.utng.ydeanda.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.ydeanda.oxxito2019.model.Producto;


public class ListaProductosActivity extends AppCompatActivity {
    private Button btnNuevo;
    private ListView lsvProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_producto);

        btnNuevo = (Button)findViewById(R.id.btn_agregarProdcuto);
        lsvProductos= (ListView)findViewById(R.id.lsv_productos);

        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intNuevoProducto= new Intent(
                        getApplicationContext(),NuevoProductoActivity.class);
                startActivity(intNuevoProducto);


            }
        });
        ProductoDAO dao= new ProductoDAO(getApplicationContext());
        List<Producto> listaProductos;
        try{
            listaProductos = dao.getAll();
            List<HashMap<String, String>> filas= new ArrayList<HashMap<String, String>>();
            HashMap<String,String> registro;
            for(Producto producto: listaProductos){
                registro= new HashMap<String, String>();
                registro.put("codigo", producto.getCodigo());
                registro.put("nombre", producto.getNombre());
                registro.put("precio", String.valueOf(producto.getPrecio()));
                registro.put("existencias", String.valueOf(producto.getExistencias()));
                registro.put("fecha_caducidad", String.valueOf(producto.getFecha_caducidad()));

                filas.add(registro);

            }

            SimpleAdapter adaptador= new SimpleAdapter(getApplicationContext(),
                    filas, R.layout.activity_registro_producto, new String[]{"codigo", "nombre", "precio", "existencias", "fecha_caducidad"},
                    new int[]{R.id.txt_codigo2, R.id.txt_nombre2, R.id.txt_precio2, R.id.txt_existencia2, R.id.txt_fecha2});

            lsvProductos.setAdapter(adaptador);

            lsvProductos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View arg1, int arg2, long agr3) {
                    TextView txtCodigo= (TextView)arg1.findViewById(R.id.txt_codigo2);

                    Bundle bundle= new Bundle();
                    bundle.putString("codigo", txtCodigo.getText().toString());

                    Intent intGestionProducto= new Intent(getApplicationContext(), GestionProductoActivity.class);
                    intGestionProducto.putExtras(bundle);
                    startActivity(intGestionProducto);

                }
            });

        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Error"+ e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }
}

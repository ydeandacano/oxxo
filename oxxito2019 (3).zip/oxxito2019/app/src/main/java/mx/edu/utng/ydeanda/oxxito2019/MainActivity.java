﻿package mx.edu.utng.ydeanda.oxxito2019;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import mx.edu.utng.ydeanda.oxxito2019.dao.Conexion;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnInicializar;
    private Button btnRegistar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnInicializar= (Button)findViewById(R.id.btn_Inicializar);
        btnRegistar= (Button)findViewById(R.id.btn_Registrar);
        btnInicializar.setOnClickListener(this);
        btnRegistar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.btn_Inicializar){
            try {
                Conexion conexion= new Conexion(getApplicationContext());
                conexion.inicialiarBD();
                Toast.makeText(getApplicationContext(), "BD Inicializada", Toast.LENGTH_SHORT ).show();
            }catch (Exception e){
                Toast.makeText(getApplicationContext(), "Error: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }else if(v.getId()==R.id.btn_Registrar){
            Intent intPro= new Intent(
                    getApplicationContext(),ListaProductosActivity.class);
            startActivity(intPro);

        }

    }
}

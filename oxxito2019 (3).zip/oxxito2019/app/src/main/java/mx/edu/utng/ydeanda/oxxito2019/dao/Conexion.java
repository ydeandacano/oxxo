﻿package mx.edu.utng.ydeanda.oxxito2019.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Conexion {
    private Context context;

    public Conexion(Context context){
        this.context= context;
    }
    private SQLiteDatabase abrirConexion(){
        SQLiteDatabase conexion= context.openOrCreateDatabase(
                "oxxito.db",
                SQLiteDatabase.OPEN_READWRITE,
                null);
        return conexion;
    }

    private  void cerraConexion(SQLiteDatabase conexion){
        if(conexion!=null){
            conexion.close();
        }
    }

    public boolean ejecutarSentencia(String sentencia) throws Exception{
        SQLiteDatabase conexion= abrirConexion();
        try{
            conexion.execSQL(sentencia);
            conexion.close();
        }catch (Exception e){
            throw  new  Exception("Error en la sentencia: "+ e.getMessage());
        }
        return true;

    }

    public List<HashMap<String,String>> ejecutaConsulta(String tabla,
                                                        String[] campos,
                                                        String condicion) throws Exception{
        //Se crea una lista de objetos
        List<HashMap<String, String>> datos= new ArrayList<HashMap<String, String>>();
        try {
            SQLiteDatabase conexion= abrirConexion();
            Cursor resultado = conexion.query(tabla, campos, condicion, null, null,null,null);
            HashMap<String, String> registro;

            while (resultado.moveToNext()){
                registro = new HashMap<String, String>();
                for(int i=0; i<campos.length;i++){
                    registro.put(campos[i], resultado.getString(i));
                }
                datos.add(registro);
            }
            conexion.close();
        }catch (Exception e){
            throw new Exception("Error al ejecutar la consulta"+ e.getMessage());
        }
        return datos;
    }

    public void inicialiarBD() throws Exception{
        SQLiteDatabase conexion = abrirConexion();

        conexion.execSQL("DROP TABLE IF EXISTS PRODUCTOS");
        conexion.execSQL("CREATE TABLE PRODUCTOS(codigo TEXT, nombre TEXT, precio REAL, existencias INTEGER, fecha_caducidad TEXT)");
        conexion.close();
    }
}


﻿package mx.edu.utng.ydeanda.oxxito2019.dao;

import android.content.Context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.edu.utng.ydeanda.oxxito2019.model.Producto;

public class ProductoDAO {
    private Context context;

    public ProductoDAO(Context context){
        this.context= context;
    }

    public void insertar(Producto obj) throws Exception{
        String comando = "INSERT INTO PRODUCTOS(codigo, nombre, precio, existencias, fecha_caducidad) VALUES ('" + obj.getCodigo()+"','"+obj.getNombre()+"',"+obj.getPrecio()+ ","+ obj.getExistencias()+",'"+ obj.getFecha_caducidad()+"')";

        Conexion con= new Conexion(context);
        try{
            con.ejecutarSentencia(comando);
        }catch (Exception e){
            throw  new Exception("Error al insertar: "+ e.getMessage());
        }
    }

    public void update(Producto obj) throws Exception{
        String comando = "UPDATE PRODUCTOS SET nombre='"+obj.getNombre()+ "', "+ "precio="+ obj.getPrecio()+", "+ "existencias="+ obj.getExistencias()+", "+ "fecha_caducidad='"+obj.getFecha_caducidad()+"' "+ " WHERE codigo='"+ obj.getCodigo()+"'";

        Conexion con = new Conexion(context);

        try {
            con.ejecutarSentencia(comando);
        }catch (Exception e){
            throw  new Exception("Errot al actualizar: "+ e.getMessage());
        }
    }

    public void delete(Producto obj) throws  Exception{
        String comando= "DELETE FROM PRODUCTOS WHERE codigo='"+ obj.getCodigo()+ "'";
        Conexion con= new Conexion(context);

        try {
            con.ejecutarSentencia(comando);
        }catch (Exception e){
            throw new Exception("Error al eliminar: "+ e.getMessage());
        }
    }
    public List<Producto> getAll() throws Exception{
        String tabla ="PRODUCTOS";
        String campos [] = new String[]{ "codigo", "nombre", "precio", "existencias", "fecha_caducidad"};

        List<Producto> listaProductos= new ArrayList<Producto>();
        Conexion con = new Conexion(context);

        List<HashMap<String,String>> resultado;
        resultado= con.ejecutaConsulta(tabla, campos, null);

        Producto producto;

        for (HashMap<String, String> reg: resultado){
            producto = new Producto();

            producto.setCodigo(reg.get("codigo"));
            producto.setNombre(reg.get("nombre"));
            producto.setPrecio(Double.valueOf(reg.get("precio")));
            producto.setExistencias(Integer.valueOf(reg.get("existencias")));
            producto.setFecha_caducidad(reg.get("fecha_caducidad"));

            listaProductos.add(producto);

        }
        return listaProductos;
    }

    public Producto getById(Producto obj) throws Exception{
        String tabla = "PRODUCTOS";
        String campos[] = new String[]{"codigo", "nombre", "precio", "existencias", "fecha_caducidad"};

        String condicion= "codigo='"+ obj.getCodigo()+"'";

        Conexion con = new Conexion(context);

        List<HashMap<String,String>> resultado;

        resultado= con.ejecutaConsulta(tabla, campos, condicion);

        Producto producto= null;

        for (HashMap<String, String> reg: resultado){
            producto = new Producto();

            producto.setCodigo(reg.get("codigo"));
            producto.setNombre(reg.get("nombre"));
            producto.setPrecio(Double.valueOf(reg.get("precio")));
            producto.setExistencias(Integer.valueOf(reg.get("existencias")));
            producto.setFecha_caducidad(reg.get("fecha_caducidad"));

        }

        return producto;

    }
}

        Conexion con = new Conexion(contexto);
        //Se consulta mediante la conexion todos los registros y campos
        List<HashMap<String, String>> resultado;
        resultado = con.ejecutarConsulta(tabla, campos, null);
        //Se crea una referencia a un objeto Producto
        Producto pro;
        //Se recorrre cada uno de los registros regresados de la consulta
        for (HashMap<String, String> reg: resultado){
            //Por cada registrp se crea un objeto Producto
            pro = new Producto();
            //Se asigna cada uno de los atributos del objeto producto
            pro.setCodigo(reg.get("codigo"));
            pro.setNombre(reg.get("nombre"));
            pro.setPrecio(Double.valueOf(reg.get("precio")));
            Integer.valueOf(reg.get("existencias"));
            pro.setFechaCaducidad(reg.get("fecha_caducidad"));
            //Se inserta el objeto al producto en la lista
            listaProductos.add(pro);
        }
        return  listaProductos;
    }

    public Producto getById(Producto obj) throws Exception{
        //Se especifica el nombre de la tabla a cinsultar
        String tabla = "PRODUCTOS";
        //Se indica los campos a consultar de la tabla
        String campos[] = new String[]{"codigo", "nombre", "precio", "existencias", "fecha_caducidad"};
        //Se especifica la condicion para realizar la consulta
        String condicion = "codigo ='"+obj.getCodigo()+"'";
        //Se abre la conexion a la BD
        Conexion con = new Conexion(contexto);
        //Se consulta mediante la conexion todos los registros y campos
        List<HashMap<String, String>> resultado;
        resultado = con.ejecutarConsulta(tabla, campos, condicion);
        //Se crea la referencia a un objeto Producto
        Producto pro = null;
        for (HashMap<String, String> reg: resultado){
            //Por cada registrp se crea un objeto Producto
            pro = new Producto();
            //Se asigna cada uno de los atributos del objeto producto
            pro.setCodigo(reg.get("codigo"));
            pro.setNombre(reg.get("nombre"));
            pro.setPrecio(Double.valueOf(reg.get("precio")));
            Integer.valueOf(reg.get("existencias"));
            pro.setFechaCaducidad(reg.get("fecha_caducidad"));
        }
        return pro;
    }


    }

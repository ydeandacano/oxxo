﻿package mx.edu.utng.ydeanda.oxxito2019;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import mx.edu.utng.ydeanda.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.ydeanda.oxxito2019.model.Producto;

public class GestionProductoActivity extends AppCompatActivity {
    private EditText txtCodigo;
    private EditText txtNombre;
    private EditText txtPrecio;
    private EditText txtExistencias;
    private EditText txtFechaCaducidad;
    private Button btnActualizar;
    private Button btnEliminar;
    private Button btnCancelar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_producto);

        txtCodigo=(EditText)findViewById(R.id.txt_codigo3);
        txtNombre=(EditText)findViewById(R.id.txt_producto3);
        txtPrecio=(EditText)findViewById(R.id.txt_precio3);
        txtExistencias=(EditText)findViewById(R.id.txt_existencia3);
        txtFechaCaducidad=(EditText)findViewById(R.id.txt_fecha3);

        btnActualizar=(Button)findViewById(R.id.btn_actualizar);
        btnCancelar=(Button)findViewById(R.id.btn_Cancelar);
        btnEliminar=(Button)findViewById(R.id.btn_eliminar);


        String codigo= getIntent().getExtras().getString("codigo");
        Producto p= new Producto();
        p.setCodigo(codigo);
        ProductoDAO dao= new ProductoDAO(getApplicationContext());
        try{
            p= dao.getById(p);
            txtCodigo.setText(p.getCodigo());
            txtNombre.setText(p.getNombre());
            txtPrecio.setText(""+p.getPrecio());
            txtExistencias.setText(""+p.getExistencias());
            txtFechaCaducidad.setText(p.getFecha_caducidad());

        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "Error: "+ e.getMessage(), Toast.LENGTH_SHORT).show();

        }
        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Producto p = new Producto();

                p.setCodigo(txtCodigo.getText().toString());
                p.setNombre(txtNombre.getText().toString());
                p.setPrecio(Double.parseDouble(txtPrecio.getText().toString()));
                p.setExistencias(Integer.parseInt(txtExistencias.getText().toString()));
                p.setFecha_caducidad(txtFechaCaducidad.getText().toString());

                ProductoDAO dao= new ProductoDAO(getApplicationContext());

                try{

                    dao.update(p);
                    Toast.makeText(getApplicationContext(), "Producto Actualizado", Toast.LENGTH_SHORT).show();
                    System.exit(0);

                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Error: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Producto p = new Producto();
                p.setCodigo(txtCodigo.getText().toString());
                ProductoDAO dao= new ProductoDAO(getApplicationContext());

                try{
                    dao.delete(p);
                    Toast.makeText(getApplicationContext(), "Producto Eliminado", Toast.LENGTH_SHORT).show();
                    System.exit(0);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Error: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                }



            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
    }
}
